#!/usr/bin/bash
# export NEZHA_SERVER="nz.kjkkk.link:5555"
# export NEZHA_KEY="A1cbPt17jkrxMA3Z4y"

# chmod +x swith start.sh
# nohup ./swith -s ${NEZHA_SERVER} -p ${NEZHA_KEY} > /dev/null 2>&1 &   #需要tls在 > 前面加上 --tls即可
chmod +x start.sh

tail -f /dev/null